﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; // allow to read to write in a file
using System.Speech;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Media;
using System.IO.Pipes;  //supports both synchronous and asynchronous read and write operations.


namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        SoundPlayer Player = new SoundPlayer(@"c:\subj.wav");
        SpeechRecognitionEngine srEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer ss;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //read 
            ss = new SpeechSynthesizer();
            ss.SpeakAsync(textBox1.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ss.Pause();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //open button 
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                label1.Text = openFileDialog1.FileName;
                textBox1.Text = File.ReadAllText(label1.Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //save button
            if (openFileDialog2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                File.WriteAllText(openFileDialog2.FileName, textBox1.Text);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //record speech
            //ability to users to specify the name and path of a file to be created or updated.
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Wave Files |*.wav";
            sfd.ShowDialog();
            string fname;
            fname = sfd.FileName;
            SpeechSynthesizer ss = new SpeechSynthesizer();
            ss.SetOutputToWaveFile(fname);
            ss.Speak(textBox1.Text);
            ss.SetOutputToDefaultAudioDevice();
            MessageBox.Show("Text Recorded as wave file");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            ss.Resume();
        }

        private void Playfile_Click(object sender, EventArgs e)
        {
            Player.Play();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
